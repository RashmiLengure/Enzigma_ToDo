// Get tasks from localStorage or initialize with an empty array
export const getTasks = () => {
    const tasks = localStorage.getItem('tasks');
    return tasks ? JSON.parse(tasks) : [];
  };
   
  // Add a new task to localStorage
  export const addTask = (newTask) => {
    const tasks = getTasks();
    tasks.push(newTask);
    localStorage.setItem('tasks', JSON.stringify(tasks));
  };
   
  // Update an existing task in localStorage
  export const updateTask = (index, updatedTask) => {
    const tasks = getTasks();
    tasks[index] = updatedTask;
    localStorage.setItem('tasks', JSON.stringify(tasks));
  };
   
  // Delete a task from localStorage
  export const deleteTask = (index) => {
    const tasks = getTasks();
    tasks.splice(index, 1);  // Remove the task at the given index
    localStorage.setItem('tasks', JSON.stringify(tasks));
  };