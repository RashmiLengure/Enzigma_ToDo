import logo from './logo.svg';
import './App.css';
import TaskList from './components/TaskList';
import TaskForm from './components/TaskForm';
import { useEffect, useState } from 'react';
import 'font-awesome/css/font-awesome.min.css'
import { addTask, deleteTask, getTasks, updateTask } from './service/TaskService';
import Modal from './Modal';
import ConfirmationModal from './ConfirmationModal';

function App() {

  const[tasks, setTasks]=useState([]);
  const[editingTaskIndex, setEditingTaskIndex]=useState(null);
  const[currentTask, setCurrentTask]=useState({
    assignedTo: '',
    status: 'Not Started',
    dueDate:'',
    priority: 'Normal',
    description:'',
  });

  const [showForm, setShowForm] = useState(false); // State to control form visibility
  const [showConfirmation, setShowConfirmation] = useState(false); // State for confirmation modal
  const [taskToDelete, setTaskToDelete] = useState(null); // Store the task to delete


  //Load tasks from local storage 
  useEffect(() => {
    setTasks(getTasks());
  }, [])

  const handleAddTask = (newTask) => {
    addTask(newTask);
    refreshTasks();
  };
 

  const handleDeleteTask = (taskIndex) => {
    setTaskToDelete(tasks[taskIndex]);
    setShowConfirmation(true);
  };
 
  const confirmDeleteTask = () => {
deleteTask(taskToDelete.id);
    refreshTasks();
    setShowConfirmation(false);
    setTaskToDelete(null);
  };

  const handleEditTask = (taskIndex) => {
    setEditingTaskIndex(taskIndex);
    setCurrentTask(tasks[taskIndex]);
    setShowForm(true)
  };

  const handleUpdateTask = (updatedTask) => {
    updateTask(editingTaskIndex, updatedTask);
    setEditingTaskIndex(null);
    resetCurrentTask();
    setShowForm(false);
    refreshTasks();
  };

  const refreshTasks = () => {
    setTasks(getTasks());  // Update the tasks after every operation
  }

  const resetCurrentTask = () => {
    setCurrentTask({
      assignedTo: '',
      status: 'Not Started',
      dueDate: '',
      priority: 'Normal',
      description: '',
    });
  };

  return (<center>
    <div className="slds-grid slds-wrap slds-p-around_large container">
      {/* Header Section */}
      <div className="slds-col slds-size_1-of-1 slds-text-heading_large" style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginTop:'70px' }}>
        <div style={{ display: 'flex', alignItems: 'center' }}>
          <i className="fa fa-tasks" style={{ backgroundColor: '#80051a', color: 'white', padding: '5px', borderRadius: '5px', marginRight: '10px' , fontSize:'50px'}}></i>
          <span style={{fontWeight: 'bold', fontSize:'24px'}}>Tasks</span>
        </div>
        
        <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'flex-end' }}>
          <div style={{ display: 'flex', alignItems: 'center' }}>
            <button className="slds-button slds-button_neutral" style={{ width: '160px', backgroundColor: '#edcc66', color: 'gray', border: '1px solid gray' }} onClick={() => setShowForm(true)}>New Task</button>
            <button className="slds-button slds-button_brand" style={{  width: '160px', backgroundColor: '#edcc66', color: 'gray', border: '1px solid gray' }} onClick={refreshTasks}>Refresh</button> {/* Removed border */}
          </div>

           {/* Modal for the TaskForm */}
      <Modal isOpen={showForm} onClose={() => setShowForm(false)}>
        <TaskForm
          addTask={handleAddTask}
          currentTask={currentTask}
          editingTaskIndex={editingTaskIndex}
          updateTask={handleUpdateTask}
          setShowForm={setShowForm} // Pass down the setShowForm function
        />
      </Modal>

      <ConfirmationModal
        isOpen={showConfirmation}
        onClose={() => setShowConfirmation(false)}
        onConfirm={confirmDeleteTask}
        task={taskToDelete}
      />


          {/* Search Input Below the Buttons */}
          <div style={{ position: 'relative', marginTop: '5px', width: '100%' }}>
           
            <input
              type="text"
              className="slds-input"
              placeholder="Search"
              style={{ paddingLeft: '30px', width: '100%' }} // Added padding to avoid overlap with icon
            />
             <i className="fa fa-search" style={{ position: 'absolute', left: '300px', top: '50%', transform: 'translateY(-50%)', color: 'gray' }}></i>
        </div>
      </div>
    </div>
    
      {/* Task List Section */}
      <div className="slds-col slds-size_1-of-1 slds-m-top_medium" style={{marginTop: '20px'}}>
        <TaskList
          tasks={tasks}
          deleteTask={handleDeleteTask}
          editTask={handleEditTask}
        />
      </div>
 
      
 
      {/* Footer Section */}
      <div className="slds-col slds-size_1-of-1 slds-m-top_medium slds-text-align_center" style={{marginTop:'20px'}}>
        <button className="slds-button slds-button_neutral">« First</button>
        <button className="slds-button slds-button_neutral">&lt; Prev</button>
        <span className="slds-text-body_regular slds-m-horizontal_xx-small">1</span>
        <button className="slds-button slds-button_neutral">Next &gt;</button>
        <button className="slds-button slds-button_neutral">Last »</button>
      </div>
    </div>
 
    </center>
      );
}

export default App;
