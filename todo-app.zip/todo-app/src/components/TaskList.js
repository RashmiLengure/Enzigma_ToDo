import React, { useState } from "react";
import "bootstrap/dist/css/bootstrap.min.css";
import "../TaskList.css"
import PropTypes from 'prop-types';

const TaskList = ({ tasks, deleteTask, editTask }) => {
  return (
    <div>
      <h2 style={{ marginBottom: '20px' }}>Task List</h2>
      <table id="customers">
        <thead>
          <tr>
            <th>Assigned To</th>
            <th>Status</th>
            <th>Due Date</th>
            <th>Priority</th>
            <th>Comments</th>
            <th>Actions</th>
          </tr>
        </thead>
        <tbody>
          {tasks.map((task, index) => (
            <tr key={index}>
              <td>{task.assignedTo}</td>
              <td>{task.status}</td>
              <td>{task.dueDate}</td>
              <td>{task.priority}</td>
              <td>{task.comments}</td>
              <td>
                <button onClick={() => editTask(index)} style={{width: '100px', backgroundColor: '#72d7f1', color:'white', border: 'none'}}>Edit</button>
                <button onClick={() => deleteTask(index)} style={{width: '100px', marginLeft:'10px' ,backgroundColor: '#cd0000',border:'none', color:'white'}}>Delete</button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};
 
TaskList.propTypes = {
  tasks: PropTypes.array.isRequired,
  deleteTask: PropTypes.func.isRequired,
  editTask: PropTypes.func.isRequired,
};

export default TaskList;
