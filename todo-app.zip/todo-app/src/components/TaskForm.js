import React, { useState, useEffect } from "react";
import "bootstrap/dist/css/bootstrap.min.css"; // Import Bootstrap
import PropTypes from 'prop-types';

const TaskForm = ({ addTask, currentTask, editingTaskIndex, updateTask, setShowForm }) => {
  const [assignedTo, setAssignedTo] = useState(currentTask.assignedTo || '');
  const [status, setStatus] = useState(currentTask.status || 'Not Started');
  const [dueDate, setDueDate] = useState(currentTask.dueDate || '');
  const [priority, setPriority] = useState(currentTask.priority || 'Normal');
  const [comments, setComments] = useState(currentTask.comments || '');
 
  useEffect(() => {
    if (editingTaskIndex !== null) {
      setAssignedTo(currentTask.assignedTo);
      setStatus(currentTask.status);
      setDueDate(currentTask.dueDate);
      setPriority(currentTask.priority);
      setComments(currentTask.comments);
    } else {
      resetForm();
    }
  }, [currentTask, editingTaskIndex]);
 
  const resetForm = () => {
    setAssignedTo('');
    setStatus('Not Started');
    setDueDate('');
    setPriority('Normal');
    setComments('');
  };
 
  const handleSubmit = (e) => {
    e.preventDefault();
    const newTask = {
      assignedTo,
      status,
      dueDate,
      priority,
      comments,
    };
 
    if (editingTaskIndex !== null) {
      updateTask(newTask);
    } else {
      addTask(newTask);
    }
    resetForm();
    setShowForm(false); // Close the modal after submitting
  };
 
  return (
    <form onSubmit={handleSubmit}>
      <table>
        <tbody>
          <tr>
            <td><label htmlFor="assignedTo">Assigned To:</label></td>
            <td>
              <input
                type="text"
                id="assignedTo"
                value={assignedTo}
                onChange={(e) => setAssignedTo(e.target.value)}
                required
              />
            </td>
          </tr>
          <tr>
            <td><label htmlFor="status">Status:</label></td>
            <td>
              <select
                id="status"
                value={status}
                onChange={(e) => setStatus(e.target.value)}
              >
                <option value="Not Started">Not Started</option>
                <option value="In Progress">In Progress</option>
                <option value="Completed">Completed</option>
              </select>
            </td>
          </tr>
          <tr>
            <td><label htmlFor="dueDate">Due Date:</label></td>
            <td>
              <input
                type="date"
                id="dueDate"
                value={dueDate}
                onChange={(e) => setDueDate(e.target.value)}
                required
              />
            </td>
          </tr>
          <tr>
            <td><label htmlFor="priority">Priority:</label></td>
            <td>
              <select
                id="priority"
                value={priority}
                onChange={(e) => setPriority(e.target.value)}
              >
                <option value="Normal">Normal</option>
                <option value="High">High</option>
                <option value="Low">Low</option>
              </select>
            </td>
          </tr>
          <tr>
            <td><label htmlFor="comments">Comments:</label></td>
            <td>
              <textarea
                id="comments"
                value={comments}
                onChange={(e) => setComments(e.target.value)}
                rows="4"
              />
            </td>
          </tr>
          <tr>
            <td colSpan="2">
              <button type="submit" className="slds-button slds-button_brand">
                {editingTaskIndex !== null ? 'Update Task' : 'Add Task'}
              </button>
            </td>
          </tr>
        </tbody>
      </table>
    </form>
  );
};
 
export default TaskForm;