import React from 'react';
 
const ConfirmationModal = ({ isOpen, onClose, onConfirm, task }) => {
  if (!isOpen) return null;
 
  return (
    <div className="modal">
      <div className="modal-content">
        <h2>Confirm Deletion</h2>
        <p>Are you sure you want to delete the task assigned to <strong>{task.assignedTo}</strong>?</p>
        <div className="modal-actions">
          <button onClick={onConfirm}>Yes, Delete</button>
          <button onClick={onClose}>Cancel</button>
        </div>
      </div>
    </div>
  );
};
 
export default ConfirmationModal;